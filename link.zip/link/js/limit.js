$("body").click(function(e) {
	if (e.target == document.getElementsByClassName("menustart")[0].children[0]) {
		if ($(".nav>.container").children().eq(0).css("display") != "none") {
			$.fn.dianji($(".twomenupc"), 0);
			$(".menustart>a").css("color", "black");
			console.log(e.target == document.getElementsByClassName("menustart")[0].children[0])
		} else {
			$.fn.dianji($(".twomenumd"), 0)
		}
	} else {
		$(".twomenupc").hide(0);
		$(".menustart>a").css("color", "white");
	}
})
$(".icon-iconfontmofangdaohang").click(function() {
	if ($(".mdtwomenubutton").css("display") == "none") {
		$(".mdtwomenubutton").slideDown(200);
	} else {
		$(".mdtwomenubutton").slideUp(200);
	}
})
$(".icon-fenxiang").click(function() {
	$.fn.dianji($(".share"), 0)
})
/* jqury封装方法 */
$.fn.dianji = function(thisdom, s) {
	if (thisdom.css("display") == "none") {
		thisdom.show(s);
	} else {
		thisdom.hide(s);
	}
}
/* introDucemdBanner轮播 */
var kongzhimdlunbo = 1,
	jiedian = 1;
introDucemdBannerlunbo = setInterval(introDucemdBannerfunction, 2000);

function introDucemdBannerfunction() {
	if (kongzhimdlunbo == 4) {
		kongzhimdlunbo = 0;
		$(".introDucemdBanner>ul").css("left", -kongzhimdlunbo * 100 + "%")
	}
	kongzhimdlunbo++;
	$(".ruididi>li").eq(kongzhimdlunbo - 1).css("background", "#ff8814").siblings().css("background", "");
	$(".introDucemdBanner>ul").stop(true, false).animate({
		"left": -kongzhimdlunbo * 100 + "%"
	}, 1000)
}

	var ruididijisuan=0;
$(".introDucemdBanner").on("touchstart",function(e){
	e=e||window.event;
	ruididijisuan=e.originalEvent.targetTouches[0].pageX;
	console.log(ruididijisuan)
})
$(".introDucemdBanner").on("touchend",function(e){
	e=e||window.event;
	ruididijisuan=ruididijisuan-e.originalEvent.changedTouches[0].pageX;
	if (ruididijisuan>0) {
		$(".introDucemdBannerright").trigger("click")
	} else if(ruididijisuan<0){
		$(".introDucemdBannerleft").trigger("click")
	}
})


$(".introDucemdBannerright").click(function() {
	if (jiedian) {
		jiedian = 0;
		clearInterval(introDucemdBannerlunbo);
		if (kongzhimdlunbo == 4) {
			kongzhimdlunbo = 0;
			$(".introDucemdBanner>ul").css("left", -kongzhimdlunbo * 100 + "%")
		}
		kongzhimdlunbo++;
		$(".ruididi>li").eq(kongzhimdlunbo - 1).css("background", "#ff8814").siblings().css("background", "");
		$(".introDucemdBanner>ul").stop(true, false).animate({
			"left": -kongzhimdlunbo * 100 + "%"
		}, 1000, function() {
			introDucemdBannerlunbo = setInterval(introDucemdBannerfunction, 2000);
			jiedian = 1;
		})
	}

})




$(".introDucemdBannerleft").click(function() {
	if (jiedian) {
		jiedian = 0;
		clearInterval(introDucemdBannerlunbo);
		if (kongzhimdlunbo == 0) {
			kongzhimdlunbo = 4;
			$(".introDucemdBanner>ul").css("left", -kongzhimdlunbo * 100 + "%")
		}
		kongzhimdlunbo--;
		$(".ruididi>li").eq(kongzhimdlunbo - 1).css("background", "#ff8814").siblings().css("background", "");
		$(".introDucemdBanner>ul").stop(true, false).animate({
			"left": -kongzhimdlunbo * 100 + "%"
		}, 1000, function() {
			introDucemdBannerlunbo = setInterval(introDucemdBannerfunction, 2000);
			jiedian = 1;
		})
	}
})
$(".ruididi>li").click(function() {
	clearInterval(introDucemdBannerlunbo);
	kongzhimdlunbo = $(this).index() + 1;
	$(this).css("background", "#ff8814").siblings().css("background", "");
	$(".introDucemdBanner>ul").stop(true, false).animate({
		"left": -($(this).index() + 1) * 100 + "%"
	}, 1000, function() {
		introDucemdBannerlunbo = setInterval(introDucemdBannerfunction, 2000);
	})
})
