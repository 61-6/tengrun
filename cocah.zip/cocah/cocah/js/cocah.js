$(function(){
    $.ajax({
        url:'http://www.qhdlink-student.top/student/coach.php',
        type:'post',
        dataType:'JSON',
        data:{
            'username':'zsy',
            'userpwd':12345678,
            'userclass':61,
            'type':2,
        },
        success:function(a){
            console.log(a);
            str='',
            $.each(a,function(i,v){
                //console.log(v.path_coach);
                //console.log(v.evaluate_coach);
                var z;
                var z=v.evaluate_coach;
                console.log(z);

                strr='';
               for(var i=0;i<z;i++){
                   strr+='<img src="img/cocah/coachGold.png">'
               }
                str+='<div class="col-md-5 col-sm-11 col-xs-11 jlone" style="margin-left:5%;display:-webkit-flex;display:-ms-flex;display:-moz-flex;align-items:center;"><div class="col-md-4  col-sm-6 col-xs-6" style="position: relative;height:100%;line-height:100%;"><img src="http://www.qhdlink-student.top/'+v.path_coach+'" style="width:100%;height:auto;display:inline;"></div><div class="col-md-1 visible-md "></div><div class="col-md-7  col-sm-6 col-xs-6" style="position: relative;"><h4>'+v.name_coach+'</h4><p style="position: absolute; right:0;top:10px;">'+strr+'</p><p>驾临：'+v.dage_coach+'</p><p>教龄:'+v.tage_coach+'</p><p>'+v.type_coach+'</p></div></div>'
            })
            $('.jladd').append(str);
        }
    
    })
});
